package util;

public class SpeakerController {

    //MQTT subscriber that subscribes to data with authentication to the main server
    /*
    the data subscribed to would be the uuid of the base station '-s'
     */
}
